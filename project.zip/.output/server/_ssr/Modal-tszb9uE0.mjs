import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Modal-tszb9uE0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var getWebApp = () => typeof window === "undefined" ? void 0 : window.Telegram?.WebApp;
function initTelegram() {
	const wa = getWebApp();
	if (!wa) return;
	try {
		wa.ready();
		wa.expand();
		wa.setHeaderColor?.("#070B14");
		wa.setBackgroundColor?.("#070B14");
	} catch {}
}
function haptic() {
	try {
		getWebApp()?.HapticFeedback?.impactOccurred("light");
	} catch {}
}
/** Display-only identity. Unverified: never use as proof of identity. */
function useTelegramUser() {
	const [u, setU] = (0, import_react.useState)({
		name: "Демо-пилот",
		id: null,
		photo: null,
		demo: true
	});
	(0, import_react.useEffect)(() => {
		const user = getWebApp()?.initDataUnsafe?.user;
		if (user?.first_name) setU({
			name: [user.first_name, user.last_name].filter(Boolean).join(" "),
			id: user.id ?? null,
			photo: user.photo_url ?? null,
			demo: false
		});
	}, []);
	return u;
}
function Modal({ open, onClose, title, children }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-background/80 backdrop-blur-sm sm:items-center",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-[430px] animate-in slide-in-from-bottom-8 fade-in rounded-t-3xl border border-border bg-card p-5 pb-safe sm:rounded-3xl",
			onClick: (e) => e.stopPropagation(),
			role: "dialog",
			"aria-label": title,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					"aria-label": "Закрыть",
					className: "grid size-8 place-items-center rounded-full bg-elevated text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm leading-relaxed text-muted-foreground",
				children
			})]
		})
	});
}
//#endregion
export { useTelegramUser as i, haptic as n, initTelegram as r, Modal as t };
