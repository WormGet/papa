import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Starfield-M3FbFC92.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var rocket_default = "/assets/rocket-Bnd1mONP.png";
function seeded(n, seed) {
	let s = seed;
	const r = () => (s = s * 16807 % 2147483647) / 2147483647;
	return Array.from({ length: n }, () => ({
		x: r() * 100,
		y: r() * 100,
		s: r() * 1.6 + .6,
		d: r() * 3
	}));
}
var A = seeded(45, 11);
var B = seeded(20, 97);
function Layer({ stars, speed, big }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-x-0 -top-full h-[200%] animate-stars",
		style: { ["--stars-speed"]: speed },
		children: [0, 50].map((off) => stars.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `absolute rounded-full bg-foreground ${big ? "animate-twinkle" : "opacity-60"}`,
			style: {
				left: `${p.x}%`,
				top: `${p.y / 2 + off}%`,
				width: p.s * (big ? 1.4 : 1),
				height: p.s * (big ? 1.4 : 1),
				animationDelay: `${p.d}s`
			}
		}, `${off}-${i}`)))
	});
}
var Starfield = (0, import_react.memo)(function Starfield({ fast = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 overflow-hidden",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layer, {
			stars: A,
			speed: fast ? "6s" : "80s"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layer, {
			stars: B,
			speed: fast ? "3.5s" : "45s",
			big: true
		})]
	});
});
//#endregion
export { rocket_default as n, Starfield as t };
