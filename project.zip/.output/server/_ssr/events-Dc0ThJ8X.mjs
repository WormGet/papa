import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Trophy, p as CalendarDays } from "../_libs/lucide-react.mjs";
import { n as rocket_default, t as Starfield } from "./Starfield-M3FbFC92.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/events-Dc0ThJ8X.js
var import_jsx_runtime = require_jsx_runtime();
var PAST = [
	{
		name: "Конкурс 1500 $ROCKET",
		date: "Ивент · 20 окт",
		note: "Завершено"
	},
	{
		name: "Орбитальная неделя",
		date: "Ивент · 05 окт",
		note: "Завершено"
	},
	{
		name: "Первый старт",
		date: "Ивент · 21 сен",
		note: "Завершено"
	}
];
function EventsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5 pt-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-extrabold",
				children: "События"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden rounded-3xl border border-border bg-space p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: rocket_default,
						alt: "",
						width: 768,
						height: 1024,
						loading: "lazy",
						className: "absolute -right-4 -bottom-6 w-32 rotate-[30deg] opacity-90"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative max-w-[65%]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-success/15 px-2.5 py-1 text-[11px] font-bold text-success",
								children: "ДЕМО · СКОРО"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-xl font-black leading-tight",
								children: "Марсианский рывок"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: "Пример события: поймайте множитель 5x и выше. Награды — только виртуальные $ROCKET."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex items-center gap-1.5 text-xs text-cyan",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "size-4" }), " Даты будут объявлены"]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 text-sm font-bold text-muted-foreground",
				children: "История событий (пример)"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: PAST.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 rounded-2xl border border-border bg-card p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-10 place-items-center rounded-xl bg-accent text-cyan",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-semibold",
								children: p.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: p.date
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: p.note
						})
					]
				}, p.name))
			})] })
		]
	});
}
//#endregion
export { EventsPage as component };
