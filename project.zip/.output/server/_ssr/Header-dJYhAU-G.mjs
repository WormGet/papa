import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as Plus } from "../_libs/lucide-react.mjs";
import { d as useGame, n as StarsIcon, t as RocketCoin } from "./utils-Bv23y0fo.mjs";
import { i as useTelegramUser, t as Modal } from "./Modal-tszb9uE0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Header-dJYhAU-G.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BalancePill({ icon, value, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-8 items-center gap-1.5 rounded-full border border-border bg-card pl-1.5 pr-1.5 text-[13px] font-bold tabular-nums",
		children: [
			icon,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pr-1",
				children: value.toLocaleString("ru-RU")
			}),
			children
		]
	});
}
function Avatar({ size = "size-9" }) {
	const u = useTelegramUser();
	const letter = (u.name || "П").charAt(0).toUpperCase();
	return u.photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: u.photo,
		alt: u.name,
		className: `${size} rounded-full border-2 border-electric object-cover glow-blue`
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `${size} grid place-items-center rounded-full border-2 border-electric bg-gradient-primary font-bold glow-blue`,
		children: letter
	});
}
function Header() {
	const balance = useGame((s) => s.balance);
	const stars = useGame((s) => s.stars);
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "fixed inset-x-0 top-0 z-30 mx-auto max-w-[430px] border-b border-border/60 bg-background/85 px-3 pt-safe pb-2 backdrop-blur-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/profile",
					"aria-label": "Профиль",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "font-display text-[13px] font-black leading-none tracking-wider",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-foreground",
						children: "ROCKET"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-electric",
						children: "CRASH"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BalancePill, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RocketCoin, { className: "size-5" }),
						value: balance
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BalancePill, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarsIcon, { className: "size-5" }),
						value: stars,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setOpen(true),
							"aria-label": "Пополнить Stars",
							className: "grid size-5 place-items-center rounded-full bg-gradient-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
								className: "size-3.5",
								strokeWidth: 3
							})
						})
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			open,
			onClose: () => setOpen(false),
			title: "Пополнение баланса",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Пополнение Telegram Stars будет настроено позже. Сейчас платежи не подключены." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2",
				children: "Stars — отдельная валюта: в демо-игре их нельзя заработать. Игра использует только виртуальные $ROCKET без реальной ценности."
			})]
		})]
	});
}
//#endregion
export { Header as n, Avatar as t };
