import { n as __toESM } from "../_runtime.mjs";
import { i as performance_default } from "../_libs/h3-v2+rou3+srvx+unenv.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as createFileRoute, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRouteWithContext, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Trophy, r as User, s as Rocket, u as ListChecks } from "../_libs/lucide-react.mjs";
import { a as cn, o as game, s as hydrate } from "./utils-Bv23y0fo.mjs";
import { r as initTelegram } from "./Modal-tszb9uE0.mjs";
import { n as Header } from "./Header-dJYhAU-G.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-C6JJRlmI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		to: "/events",
		label: "События",
		Icon: Trophy
	},
	{
		to: "/",
		label: "Игра",
		Icon: Rocket
	},
	{
		to: "/tasks",
		label: "Задания",
		Icon: ListChecks
	},
	{
		to: "/profile",
		label: "Профиль",
		Icon: User
	}
];
function BottomNavigation() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "fixed inset-x-0 bottom-0 z-30 mx-auto max-w-[430px] border-t border-border/60 bg-background/90 px-2 pt-2 pb-safe backdrop-blur-md",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid grid-cols-4 gap-1",
			children: TABS.map(({ to, label, Icon }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to,
				activeOptions: { exact: true },
				className: "flex flex-col items-center gap-0.5 rounded-2xl py-1.5 text-[11px] font-semibold text-muted-foreground transition data-[status=active]:bg-accent data-[status=active]:text-cyan",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), label]
			}) }, to))
		})
	});
}
function NotificationToast() {
	const [t, setT] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let timer;
		game.onToast((x) => {
			setT({
				...x,
				id: Date.now()
			});
			clearTimeout(timer);
			timer = setTimeout(() => setT(null), 2600);
		});
		return () => {
			game.onToast(null);
			clearTimeout(timer);
		};
	}, []);
	if (!t) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none fixed inset-x-0 top-16 z-40 flex justify-center px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("animate-in fade-in slide-in-from-top-4 rounded-2xl border px-4 py-2.5 text-sm font-semibold backdrop-blur-md", t.kind === "success" && "border-success/40 bg-success/15 text-success glow-success", t.kind === "crash" && "border-crash/40 bg-crash/15 text-crash", t.kind === "info" && "border-border bg-card text-foreground"),
			children: t.text
		}, t.id)
	});
}
/** Drives the round state machine from one rAF loop, independent of the visible tab. */
function GameLoop() {
	(0, import_react.useEffect)(() => {
		hydrate();
		initTelegram();
		let raf = 0;
		const loop = (t) => {
			game.tick(t);
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		const iv = setInterval(() => game.tick(performance_default.now()), 250);
		return () => {
			cancelAnimationFrame(raf);
			clearInterval(iv);
		};
	}, []);
	return null;
}
var styles_default = "/assets/styles-aXBkIINz.css";
var Route$5 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover, maximum-scale=1"
			},
			{
				name: "theme-color",
				content: "#070B14"
			},
			{ title: "ROCKET CRASH" }
		],
		links: [{
			rel: "stylesheet",
			href: styles_default
		}, {
			rel: "stylesheet",
			href: "https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Orbitron:wght@700;900&display=swap"
		}],
		scripts: [{ src: "https://telegram.org/js/telegram-web-app.js" }]
	}),
	shellComponent: ({ children }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ru",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	}),
	component: () => {
		const { queryClient } = Route$5.useRouteContext();
		(0, import_react.useEffect)(() => {
			const tg = window.Telegram?.WebApp;
			if (tg) {
				tg.ready();
				tg.expand();
			}
		}, []);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
			client: queryClient,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameLoop, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "mx-auto min-h-dvh max-w-[430px] px-3 pt-[calc(max(env(safe-area-inset-top),0.5rem)+3.25rem)] pb-[calc(max(env(safe-area-inset-bottom),0.5rem)+5rem)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNavigation, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationToast, {})
			]
		});
	}
});
var $$splitComponentImporter$4 = () => import("./routes-CSp6Iu2y.mjs");
var Route$4 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "ROCKET CRASH — запусти ракету" },
		{
			name: "description",
			content: "Демо краш-игра: делайте виртуальную ставку и забирайте выигрыш до взрыва ракеты."
		},
		{
			property: "og:title",
			content: "ROCKET CRASH — запусти ракету"
		},
		{
			property: "og:description",
			content: "Демо краш-игра в Telegram на виртуальных $ROCKET."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./admin-Bjqr6B9H.mjs");
var Route$3 = createFileRoute("/admin")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./events-Dc0ThJ8X.mjs");
var Route$2 = createFileRoute("/events")({
	head: () => ({ meta: [
		{ title: "События — ROCKET CRASH" },
		{
			name: "description",
			content: "Космические события ROCKET CRASH: демо-ивенты и история."
		},
		{
			property: "og:title",
			content: "События — ROCKET CRASH"
		},
		{
			property: "og:description",
			content: "Демо-события космической краш-игры."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./profile-BDedkn73.mjs");
var Route$1 = createFileRoute("/profile")({
	head: () => ({ meta: [
		{ title: "Профиль — ROCKET CRASH" },
		{
			name: "description",
			content: "Профиль пилота: баланс, статистика и история демо-раундов."
		},
		{
			property: "og:title",
			content: "Профиль — ROCKET CRASH"
		},
		{
			property: "og:description",
			content: "Статистика и история демо-игры ROCKET CRASH."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./tasks-BzDgD9gi.mjs");
var Route = createFileRoute("/tasks")({
	head: () => ({ meta: [
		{ title: "Задания — ROCKET CRASH" },
		{
			name: "description",
			content: "Выполняйте задания и получайте виртуальные $ROCKET."
		},
		{
			property: "og:title",
			content: "Задания — ROCKET CRASH"
		},
		{
			property: "og:description",
			content: "Демо-задания с наградой в виртуальных $ROCKET."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$4.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$5
	}),
	AdminRoute: Route$3.update({
		id: "/admin",
		path: "/admin",
		getParentRoute: () => Route$5
	}),
	EventsRoute: Route$2.update({
		id: "/events",
		path: "/events",
		getParentRoute: () => Route$5
	}),
	ProfileRoute: Route$1.update({
		id: "/profile",
		path: "/profile",
		getParentRoute: () => Route$5
	}),
	TasksRoute: Route.update({
		id: "/tasks",
		path: "/tasks",
		getParentRoute: () => Route$5
	})
};
var routeTree = Route$5._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
