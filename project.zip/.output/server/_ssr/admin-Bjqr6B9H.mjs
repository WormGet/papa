import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as Key, h as ArrowLeft, i as UserPlus, o as ShieldAlert } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-Bjqr6B9H.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminPage() {
	const navigate = useNavigate();
	const [promos, setPromos] = (0, import_react.useState)([]);
	const [reward, setReward] = (0, import_react.useState)(100);
	const [maxUses, setMaxUses] = (0, import_react.useState)(10);
	const [adminTag, setAdminTag] = (0, import_react.useState)("");
	const initData = (window.Telegram?.WebApp)?.initData || "";
	const callApi = async (action, payload = {}) => {
		return (await fetch("/api", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				initData,
				action,
				...payload
			})
		})).json();
	};
	const loadPromos = async () => {
		if (!initData) return;
		const data = await callApi("get_promos");
		if (Array.isArray(data)) setPromos(data);
	};
	(0, import_react.useEffect)(() => {
		loadPromos();
	}, []);
	const handleCreate = async () => {
		await callApi("create_promo", {
			reward,
			maxUses
		});
		loadPromos();
	};
	const handleMakeAdmin = async () => {
		await callApi("make_admin", { target: adminTag });
		alert("Права выданы!");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 pt-3 pb-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => navigate({ to: "/profile" }),
					className: "p-2 bg-card rounded-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { size: 18 })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "text-xl font-bold flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {
						size: 20,
						className: "text-gold"
					}), " Админ-панель"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-card p-4 rounded-2xl space-y-3 border border-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-bold text-sm text-muted-foreground uppercase flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, { size: 14 }), " Создать промокод"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							value: reward,
							onChange: (e) => setReward(+e.target.value),
							className: "bg-surface p-2.5 rounded-xl w-1/2 text-sm",
							placeholder: "Награда"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							value: maxUses,
							onChange: (e) => setMaxUses(+e.target.value),
							className: "bg-surface p-2.5 rounded-xl w-1/2 text-sm",
							placeholder: "Активаций"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: handleCreate,
						className: "bg-electric text-black w-full py-2.5 rounded-xl font-bold text-sm",
						children: "Сгенерировать"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-card p-4 rounded-2xl space-y-3 border border-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-bold text-sm text-muted-foreground uppercase flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { size: 14 }), " Выдать админку"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						value: adminTag,
						onChange: (e) => setAdminTag(e.target.value),
						className: "bg-surface p-2.5 rounded-xl w-full text-sm",
						placeholder: "@username"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: handleMakeAdmin,
						className: "bg-gold text-black px-4 rounded-xl font-bold text-sm",
						children: "Выдать"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-card p-4 rounded-2xl space-y-3 border border-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-bold text-sm text-muted-foreground uppercase",
					children: "Список кодов"
				}), promos.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-between items-center border-b border-border pb-2 last:border-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-mono font-bold text-base text-electric",
						children: p.code
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-muted-foreground",
						children: [
							"+",
							p.reward,
							" · ",
							p.usedBy.length,
							"/",
							p.maxUses
						]
					})] })
				}, p.code))]
			})
		]
	});
}
//#endregion
export { AdminPage as component };
