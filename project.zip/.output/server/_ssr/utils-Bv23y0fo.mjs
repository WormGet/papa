import { n as __toESM } from "../_runtime.mjs";
import { i as performance_default } from "../_libs/h3-v2+rou3+srvx+unenv.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-Bv23y0fo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TIMING = {
	WAITING: 1500,
	COUNTDOWN: 5e3,
	CRASHED: 2200,
	ROUND_RESET: 1300
};
var GROWTH = .12;
var multiplierAt = (elapsedMs) => Math.floor(Math.exp(GROWTH * Math.max(0, elapsedMs) / 1e3) * 100) / 100;
function nextCrash(seed) {
	let t = seed + 1831565813 | 0;
	let r = Math.imul(t ^ t >>> 15, 1 | t);
	r = r + Math.imul(r ^ r >>> 7, 61 | r) ^ r;
	const u = ((r ^ r >>> 14) >>> 0) / 4294967296;
	return {
		crash: Math.min(30, Math.max(1.01, Math.floor(.97 / (1 - u) * 100) / 100)),
		seed: t
	};
}
var BOT_NAMES = [
	"notyourboy",
	"crypto_king",
	"rich_boy",
	"sigma",
	"alpha_male",
	"lil_peep",
	"toxic_boy",
	"sad_boy",
	"bad_girl",
	"lil_bitch",
	"fuck_cancer",
	"no_way",
	"ez_win",
	"gg_wp",
	"pro_player",
	"im_rich",
	"money_maker",
	"cash_out",
	"bet_win",
	"lucky_man",
	"son_of_a_bitch",
	"xxtentacion",
	"lil_uzi",
	"travis_scott",
	"drake",
	"kanye",
	"zxc_ghoul",
	"shadow_fiend",
	"cyber_punk",
	"neon_night",
	"dark_side",
	"light_yagami",
	"l_death_note",
	"goku_ultra",
	"naruto_uzumaki",
	"sasuke_uchiha",
	"itachi",
	"sukuna",
	"yuji",
	"megumi",
	"eren_yeager",
	"levi_ackerman",
	"mikasa",
	"armin",
	"erwin",
	"fat_cat",
	"ugly_boy",
	"stupid_girl",
	"braindead",
	"retard",
	"moron",
	"idiot",
	"genius",
	"smart_ass",
	"dumb_ass",
	"flying_pig",
	"purple_monkey",
	"blue_whale",
	"pink_panther",
	"black_cat",
	"white_dog",
	"green_frog",
	"yellow_bird",
	"red_fox",
	"orange_cat",
	"spider_man",
	"batman",
	"superman",
	"iron_man",
	"captain_america",
	"black_widow",
	"hawk_eye",
	"chat_gpt",
	"midjourney",
	"stable_diff",
	"neural_net",
	"deep_learn",
	"machine_learn",
	"data_sci",
	"big_data",
	"cloud_comp",
	"quantum",
	"ai_bot",
	"ai_god",
	"human_ai",
	"cyborg",
	"terminator",
	"matrix",
	"morpheus",
	"trinity",
	"agent_smith",
	"privet",
	"kak_dela",
	"horosho",
	"normalno",
	"krasavchik",
	"devushka",
	"muzhik",
	"anime_girl",
	"manga_boy",
	"otaku",
	"weaboo",
	"senpai",
	"kawaii",
	"minecraft",
	"roblox",
	"fortnite",
	"cs_gooo",
	"dota_2",
	"league_of_legends",
	"valorant",
	"apex_legends",
	"genshin",
	"gamer_2000",
	"pro_gamer",
	"noob_master",
	"pvp_king",
	"pve_queen",
	"speedrun",
	"glitch",
	"exploit",
	"boss",
	"kriminal",
	"avtoritet",
	"pakhan",
	"sherst",
	"kavkaz",
	"bratva",
	"chechnya",
	"dagestan",
	"armenia",
	"georgia",
	"azerb",
	"tatar",
	"bashkir",
	"chuvash",
	"ya_tebya_lyublyu",
	"ty_moy_drug",
	"my_za_rossiyu",
	"krym_nash",
	"moskva_siti",
	"spb_gorod",
	"sochi_2014",
	"kazan_2013",
	"ekb_300",
	"novosibirsk",
	"tvoy_boss",
	"tvoy_huz",
	"tvoy_papa",
	"tvoya_mama",
	"tvoy_brat",
	"tvoya_sestra",
	"tvoy_drug",
	"tvoy_vrag",
	"tvoy_angel",
	"tvoy_demon"
];
var randRange = (min, max) => {
	return Math.floor(Math.random() * (max - min + 1)) + min;
};
function getHumanAmount() {
	const r = Math.random();
	if (r < .6) {
		if (Math.random() < .4) {
			const niceNumbers = [
				10,
				20,
				30,
				50,
				70,
				100
			];
			return niceNumbers[Math.floor(Math.random() * niceNumbers.length)];
		}
		return randRange(10, 100);
	}
	if (r < .85) {
		if (Math.random() < .5) {
			const niceNumbers = [
				100,
				150,
				200,
				250,
				300,
				400,
				500
			];
			return niceNumbers[Math.floor(Math.random() * niceNumbers.length)];
		}
		return randRange(100, 500);
	}
	if (r < .97) {
		if (Math.random() < .3) {
			const niceNumbers = [
				500,
				750,
				1e3
			];
			return niceNumbers[Math.floor(Math.random() * niceNumbers.length)];
		}
		return randRange(500, 1500);
	}
	if (Math.random() < .8) return 1500;
	return randRange(1500, 2500);
}
function getHumanDelay() {
	const r = Math.random();
	if (r < .2) return randRange(4e3, 4800);
	if (r < .6) return randRange(2e3, 4e3);
	if (r < .85) return randRange(500, 2e3);
	return randRange(0, 500);
}
function getBotCount() {
	const r = Math.random();
	if (r < .3) return 1;
	if (r < .7) return 2;
	if (r < .9) return 3;
	return 4;
}
function generateBots(roundId) {
	const count = getBotCount();
	const usedNames = /* @__PURE__ */ new Set();
	const usedAmounts = /* @__PURE__ */ new Set();
	return Array.from({ length: count }, (_, id) => {
		let name = BOT_NAMES[Math.floor(Math.random() * BOT_NAMES.length)];
		let attempts = 0;
		while (usedNames.has(name) && attempts < 50) {
			name = BOT_NAMES[Math.floor(Math.random() * BOT_NAMES.length)];
			attempts++;
		}
		usedNames.add(name);
		let amount = getHumanAmount();
		attempts = 0;
		while (usedAmounts.has(amount) && attempts < 10) {
			amount = getHumanAmount();
			attempts++;
		}
		usedAmounts.add(amount);
		const delayMs = getHumanDelay();
		let target = 1.2 + Math.random() * 1.8;
		if (amount > 1e3) target = 1.1 + Math.random() * .4;
		else if (amount > 500) target = 1.2 + Math.random() * .6;
		else if (amount > 100) target = 1.3 + Math.random() * .8;
		return {
			id,
			name,
			amount,
			target: Math.round(target * 100) / 100,
			delayMs,
			isPlaced: false,
			cashed: false,
			lost: false
		};
	});
}
function initialState(now) {
	return {
		phase: "WAITING",
		phaseStartedAt: now,
		roundId: 1,
		crashPoint: 2,
		multiplier: 1,
		countdown: 5,
		bots: [],
		balance: 0,
		stars: 0,
		stake: 100,
		autoBet: false,
		autoCash: false,
		autoTarget: 2,
		bet: null,
		history: [],
		games: [],
		claimed: [],
		lastVisit: "",
		seed: now % 1e5 + 7
	};
}
var canBet = (s) => (s.phase === "WAITING" || s.phase === "COUNTDOWN" || s.phase === "ROUND_RESET") && !s.bet && s.stake >= 10 && s.stake <= s.balance;
function clampStake(stake, balance) {
	if (!Number.isFinite(stake)) return 10;
	return Math.max(10, Math.min(Math.floor(stake), Math.max(10, balance)));
}
function setStake(s, stake) {
	return {
		...s,
		stake: clampStake(stake, s.balance)
	};
}
function clampTarget(t) {
	if (!Number.isFinite(t)) return 2;
	return Math.min(100, Math.max(1.01, Math.round(t * 100) / 100));
}
function placeBet(s) {
	if (!canBet(s)) return s;
	const target = s.phase === "ROUND_RESET" ? s.roundId + 1 : s.roundId;
	return {
		...s,
		balance: s.balance - s.stake,
		bet: {
			roundId: target,
			amount: s.stake,
			status: "pending",
			payout: 0,
			cashedAt: null
		}
	};
}
function record(s, bet) {
	const rec = {
		roundId: bet.roundId,
		amount: bet.amount,
		crashPoint: s.crashPoint,
		cashedAt: bet.cashedAt,
		payout: bet.payout,
		win: bet.status === "cashed",
		ts: Date.now()
	};
	return {
		...s,
		games: [rec, ...s.games].slice(0, 50)
	};
}
function cashOut(s, at) {
	if (s.phase !== "RUNNING" || !s.bet || s.bet.status !== "active") return s;
	const m = Math.min(at ?? s.multiplier, s.crashPoint);
	const payout = Math.floor(s.bet.amount * m);
	const bet = {
		...s.bet,
		status: "cashed",
		payout,
		cashedAt: m
	};
	return record({
		...s,
		bet,
		balance: s.balance + payout
	}, bet);
}
function startRound(s, now) {
	const bet = s.bet && s.bet.roundId === s.roundId && s.bet.status === "pending" ? {
		...s.bet,
		status: "active"
	} : s.bet;
	return {
		...s,
		phase: "RUNNING",
		phaseStartedAt: now,
		multiplier: 1,
		bet
	};
}
function crash(s, now) {
	let next = {
		...s,
		phase: "CRASHED",
		phaseStartedAt: now,
		multiplier: s.crashPoint,
		history: [s.crashPoint, ...s.history].slice(0, 20)
	};
	if (next.bet && next.bet.status === "active") {
		const bet = {
			...next.bet,
			status: "lost"
		};
		next = record({
			...next,
			bet
		}, bet);
	}
	return next;
}
function beginCountdown(s, now) {
	const { crash: cp, seed } = nextCrash(s.seed);
	const roundId = s.phase === "ROUND_RESET" ? s.roundId + 1 : s.roundId;
	const bet = s.bet && (s.bet.status === "cashed" || s.bet.status === "lost") ? null : s.bet;
	let next = {
		...s,
		phase: "COUNTDOWN",
		phaseStartedAt: now,
		roundId,
		crashPoint: cp,
		seed,
		multiplier: 1,
		countdown: 5,
		bet,
		bots: generateBots(roundId)
	};
	if (next.autoBet && !next.bet) next = placeBet(next);
	return next;
}
function tick(s, now) {
	const el = now - s.phaseStartedAt;
	switch (s.phase) {
		case "WAITING": return el >= TIMING.WAITING ? beginCountdown(s, now) : s;
		case "COUNTDOWN": {
			if (el >= TIMING.COUNTDOWN) return startRound(s, now);
			let botsChanged = false;
			const updatedBots = s.bots.map((bot) => {
				if (!bot.isPlaced && el >= bot.delayMs) {
					botsChanged = true;
					return {
						...bot,
						isPlaced: true
					};
				}
				return bot;
			});
			const c = Math.ceil((TIMING.COUNTDOWN - el) / 1e3);
			if (botsChanged || c !== s.countdown) return {
				...s,
				countdown: c,
				bots: updatedBots
			};
			return s;
		}
		case "RUNNING": {
			const m = multiplierAt(el);
			let botsChanged = false;
			const updatedBots = s.bots.map((bot) => {
				if (!bot.isPlaced) return bot;
				if (!bot.cashed && !bot.lost && m >= bot.target) {
					botsChanged = true;
					return {
						...bot,
						cashed: true
					};
				}
				return bot;
			});
			if (s.autoCash && s.bet?.status === "active" && s.autoTarget <= s.crashPoint && m >= s.autoTarget) return cashOut({
				...s,
				multiplier: s.autoTarget,
				bots: updatedBots
			}, s.autoTarget);
			if (m >= s.crashPoint) {
				const finalBots = updatedBots.map((b) => b.isPlaced && !b.cashed ? {
					...b,
					lost: true
				} : b);
				return crash({
					...s,
					bots: finalBots
				}, now);
			}
			if (m !== s.multiplier || botsChanged) return {
				...s,
				multiplier: m,
				bots: updatedBots
			};
			return s;
		}
		case "CRASHED":
			if (el >= TIMING.CRASHED) {
				const bet = s.bet && (s.bet.status === "cashed" || s.bet.status === "lost") ? null : s.bet;
				return {
					...s,
					phase: "ROUND_RESET",
					phaseStartedAt: now,
					bet
				};
			}
			return s;
		case "ROUND_RESET": return el >= TIMING.ROUND_RESET ? beginCountdown(s, now) : s;
	}
}
var today = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
var TASKS = [
	{
		id: "play3",
		title: "Сыграйте 3 раунда",
		reward: 150,
		goal: 3,
		icon: "rocket"
	},
	{
		id: "firstCash",
		title: "Совершите первый вывод",
		reward: 200,
		goal: 1,
		icon: "wallet"
	},
	{
		id: "daily",
		title: "Зайдите в игру сегодня",
		reward: 50,
		goal: 1,
		icon: "calendar"
	}
];
var taskKey = (id) => id === "daily" ? `daily-${today()}` : id;
function taskProgress(s, id) {
	if (id === "play3") return s.games.length;
	if (id === "firstCash") return s.games.filter((g) => g.win).length;
	if (id === "daily") return s.lastVisit === today() ? 1 : 0;
	return 0;
}
function claimTask(s, id) {
	const t = TASKS.find((x) => x.id === id);
	const key = taskKey(id);
	if (!t || s.claimed.includes(key) || taskProgress(s, id) < t.goal) return s;
	return {
		...s,
		claimed: [...s.claimed, key],
		balance: s.balance + t.reward
	};
}
function stats(s) {
	const wins = s.games.filter((g) => g.win);
	return {
		total: s.games.length,
		wins: wins.length,
		losses: s.games.length - wins.length,
		best: wins.reduce((m, g) => Math.max(m, g.cashedAt ?? 0), 0)
	};
}
var KEY = "rocket-crash-demo-v1";
var PERSIST = [
	"balance",
	"stars",
	"stake",
	"autoBet",
	"autoCash",
	"autoTarget",
	"history",
	"games",
	"claimed",
	"lastVisit",
	"seed"
];
var SERVER_STATE = initialState(0);
var state = SERVER_STATE;
var listeners = /* @__PURE__ */ new Set();
var toastListener = null;
function persist() {
	if (typeof window === "undefined") return;
	const out = {};
	for (const k of PERSIST) out[k] = state[k];
	try {
		localStorage.setItem(KEY, JSON.stringify(out));
	} catch {}
}
function set(next, save = true) {
	if (next === state) return;
	const prev = state;
	state = next;
	if (prev.bet?.status === "active" && next.bet?.status === "cashed") toastListener?.({
		kind: "success",
		text: `Вы забрали +${next.bet.payout} $ROCKET на ${next.bet.cashedAt?.toFixed(2)}x`
	});
	if (prev.phase === "RUNNING" && next.phase === "CRASHED" && prev.bet?.status === "active") toastListener?.({
		kind: "crash",
		text: `Краш на ${next.crashPoint.toFixed(2)}x — ставка проиграна`
	});
	const persistChanged = PERSIST.some((k) => prev[k] !== next[k]);
	if (save && persistChanged) persist();
	listeners.forEach((l) => l());
}
function hydrate() {
	const now = performance_default.now();
	let saved = {};
	try {
		saved = JSON.parse(localStorage.getItem(KEY) || "{}");
	} catch {}
	state = {
		...initialState(Math.floor(Date.now())),
		...saved,
		phase: "WAITING",
		phaseStartedAt: now,
		bet: null,
		lastVisit: today(),
		bots: []
	};
	persist();
	listeners.forEach((l) => l());
}
var game = {
	get: () => state,
	tick: (now) => set(tick(state, now)),
	placeBet: () => set(placeBet(state)),
	cashOut: () => set(cashOut(state)),
	setStake: (v) => set(setStake(state, v)),
	setAutoBet: (v) => set({
		...state,
		autoBet: v
	}),
	setAutoCash: (v) => set({
		...state,
		autoCash: v
	}),
	setAutoTarget: (v) => set({
		...state,
		autoTarget: clampTarget(v)
	}),
	claimTask: (id) => set(claimTask(state, id)),
	reset: () => {
		set({
			...initialState(Math.floor(Date.now())),
			phaseStartedAt: performance_default.now(),
			lastVisit: today()
		});
	},
	onToast: (fn) => {
		toastListener = fn;
	}
};
var subscribe = (l) => {
	listeners.add(l);
	return () => listeners.delete(l);
};
function useGame(sel) {
	return (0, import_react.useSyncExternalStore)(subscribe, () => sel(state), () => sel(SERVER_STATE));
}
function RocketCoin({ className = "size-4" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		className,
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
				id: "rc-g",
				x1: "0",
				y1: "0",
				x2: "1",
				y2: "1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
					offset: "0",
					stopColor: "var(--cyan)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
					offset: "1",
					stopColor: "var(--primary)"
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "11",
				fill: "url(#rc-g)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M12 4.5c2.6 1.6 3.6 4.4 3.3 7.6l1.6 2.1-2.2.4-.8 1.6h-3.8l-.8-1.6-2.2-.4 1.6-2.1C8.4 8.9 9.4 6.1 12 4.5z",
				fill: "var(--foreground)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "9.6",
				r: "1.4",
				fill: "var(--primary)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M10.8 16.6h2.4L12 19.4z",
				fill: "var(--gold)"
			})
		]
	});
}
function StarsIcon({ className = "size-4" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		className,
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
			id: "st-g",
			x1: "0",
			y1: "0",
			x2: "0",
			y2: "1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
				offset: "0",
				stopColor: "var(--cyan)"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
				offset: "1",
				stopColor: "var(--electric)"
			})]
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M12 1.8l2.9 6.3 6.9.7-5.2 4.6 1.5 6.8L12 16.7l-6.1 3.5 1.5-6.8L2.2 8.8l6.9-.7z",
			fill: "url(#st-g)",
			stroke: "var(--foreground)",
			strokeOpacity: ".35",
			strokeWidth: ".8",
			strokeLinejoin: "round"
		})]
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
//#endregion
export { cn as a, stats as c, useGame as d, canBet as i, taskKey as l, StarsIcon as n, game as o, TASKS as r, hydrate as s, RocketCoin as t, taskProgress as u };
