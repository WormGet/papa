import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as Plus, l as Minus } from "../_libs/lucide-react.mjs";
import { n as rocket_default, t as Starfield } from "./Starfield-M3FbFC92.mjs";
import { a as cn, d as useGame, i as canBet, o as game, t as RocketCoin } from "./utils-Bv23y0fo.mjs";
import { n as haptic, t as Modal } from "./Modal-tszb9uE0.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/@radix-ui/react-switch+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CSp6Iu2y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RocketAnimation({ children }) {
	const phase = useGame((s) => s.phase);
	const m = useGame((s) => s.multiplier);
	const running = phase === "RUNNING";
	const crashed = phase === "CRASHED";
	const flying = running || crashed;
	const p = flying ? 1 - 1 / Math.pow(m, 1.1) : 0;
	const x = 14 + 64 * p;
	const y = 80 - 58 * p;
	const cx = 14 + (x - 14) * .7;
	const angle = flying ? Math.min(62, Math.atan2(x - cx, 80 - y + .001) * 180 / Math.PI * .9 + 8) : 0;
	const scale = 1 - p * .18;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-[clamp(240px,42vh,360px)] overflow-hidden rounded-3xl border border-border bg-space",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, { fast: running }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 opacity-[0.07] [background-image:linear-gradient(var(--cyan)_1px,transparent_1px),linear-gradient(90deg,var(--cyan)_1px,transparent_1px)] [background-size:32px_32px]" }),
			flying && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 100 100",
				preserveAspectRatio: "none",
				className: "absolute inset-0 size-full",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: "trail",
						x1: "0",
						y1: "1",
						x2: "1",
						y2: "0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0",
							stopColor: "var(--primary)",
							stopOpacity: "0"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "1",
							stopColor: "var(--cyan)"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: "trail-fill",
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0",
							stopColor: "var(--electric)",
							stopOpacity: ".28"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "1",
							stopColor: "var(--electric)",
							stopOpacity: "0"
						})]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: `M 2 96 Q ${cx} 96 ${x} ${y + 8} L ${x} 100 L 2 100 Z`,
						fill: "url(#trail-fill)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: `M 2 96 Q ${cx} 96 ${x} ${y + 8}`,
						fill: "none",
						stroke: crashed ? "var(--crash)" : "url(#trail)",
						strokeWidth: "1.4",
						vectorEffect: "non-scaling-stroke",
						style: {
							filter: "drop-shadow(0 0 4px var(--cyan))",
							strokeWidth: 3
						}
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("absolute w-[74px] transition-opacity duration-300", crashed && "opacity-0"),
				style: {
					left: flying ? `${x}%` : "50%",
					top: flying ? `${y}%` : "62%",
					transform: `translate(-50%,-50%) rotate(${angle}deg) scale(${flying ? scale : 1})`
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn(!flying && "animate-bob"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: rocket_default,
						alt: "Ракета",
						width: 768,
						height: 1024,
						className: "relative z-10 w-full drop-shadow-[0_0_14px_var(--electric)]"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("absolute left-1/2 top-[90%] -translate-x-1/2", !running && "opacity-40 scale-50"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-14 w-6 animate-flame rounded-b-full bg-[linear-gradient(180deg,var(--foreground),var(--cyan)_30%,var(--electric)_65%,transparent)] blur-[2px]" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-1/2 top-0 h-8 w-3 -translate-x-1/2 animate-flame rounded-b-full bg-[linear-gradient(180deg,var(--foreground),var(--gold)_60%,transparent)]" }),
							running && [
								0,
								1,
								2
							].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute left-1/2 top-10 size-1.5 animate-float-up rounded-full bg-cyan",
								style: {
									animationDelay: `${i * .3}s`,
									animationDirection: "reverse",
									marginLeft: (i - 1) * 6
								}
							}, i))
						]
					})]
				})
			}),
			crashed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute size-28 -translate-x-1/2 -translate-y-1/2",
				style: {
					left: `${x}%`,
					top: `${y}%`
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 animate-boom rounded-full bg-[radial-gradient(circle,var(--gold),var(--crash)_45%,transparent_70%)]" })
			}),
			!flying && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-[14%] left-1/2 h-2 w-28 -translate-x-1/2 rounded-full bg-electric/30 blur-md" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 flex flex-col items-center pt-6",
				children
			})
		]
	});
}
function MultiplierDisplay() {
	const phase = useGame((s) => s.phase);
	const m = useGame((s) => s.multiplier);
	const countdown = useGame((s) => s.countdown);
	const crashPoint = useGame((s) => s.crashPoint);
	const last = useGame((s) => s.history[0]);
	if (phase === "RUNNING") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "font-display text-6xl font-black tabular-nums text-foreground text-glow-cyan",
		children: [m.toFixed(2), "x"]
	});
	if (phase === "CRASHED") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs font-bold tracking-[0.3em] text-crash",
			children: "КРАШ"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "font-display text-6xl font-black tabular-nums text-crash text-glow-crash",
			children: [crashPoint.toFixed(2), "x"]
		})]
	});
	if (phase === "COUNTDOWN") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs font-semibold tracking-widest text-muted-foreground",
			children: "СТАРТ ЧЕРЕЗ"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-display text-6xl font-black text-success text-glow-success animate-in zoom-in-50 fade-in duration-300",
			children: countdown
		}, countdown)]
	});
	if (phase === "ROUND_RESET") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs font-semibold tracking-widest text-muted-foreground",
			children: "ПРОШЛЫЙ РАУНД"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "font-display text-4xl font-black text-crash/80",
			children: [last?.toFixed(2), "x"]
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-4 animate-pulse text-base font-semibold text-muted-foreground",
		children: "Ожидание ставок..."
	});
}
function RoundHistory() {
	const history = useGame((s) => s.history);
	if (!history.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-7 text-xs leading-7 text-muted-foreground",
		children: "История раундов появится здесь"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-7 gap-1.5 overflow-x-auto [scrollbar-width:none]",
		children: history.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: cn("shrink-0 rounded-full border px-2.5 py-1 font-display text-[11px] font-bold tabular-nums", h < 2 && "border-crash/40 bg-crash/10 text-crash", h >= 2 && h < 6 && "border-electric/40 bg-electric/10 text-electric", h >= 6 && "border-gold/40 bg-gold/10 text-gold"),
			children: [h.toFixed(2), "x"]
		}, `${history.length - i}`))
	});
}
function BettingControls() {
	const s = useGame((x) => x);
	const { phase, bet, stake, balance, multiplier } = s;
	const canCash = phase === "RUNNING" && bet?.status === "active";
	const pending = bet?.status === "pending";
	const betOk = canBet(s);
	const locked = !!bet || phase === "RUNNING" || phase === "CRASHED";
	let label = "СДЕЛАТЬ СТАВКУ";
	let sub = null;
	let variant = "primary";
	if (canCash) {
		label = "ЗАБРАТЬ ВЫИГРЫШ";
		sub = `${Math.floor(bet.amount * multiplier)} $ROCKET`;
		variant = "success";
	} else if (pending) {
		label = "СТАВКА ПРИНЯТА";
		sub = `${bet.amount} $ROCKET · ждём старт`;
		variant = "muted";
	} else if (bet?.status === "cashed") {
		label = "ВЫИГРЫШ ЗАБРАН";
		sub = `+${bet.payout} $ROCKET`;
		variant = "muted";
	} else if (phase === "RUNNING" || phase === "CRASHED") {
		label = "ОЖИДАНИЕ РАУНДА";
		sub = "Ставки откроются после краша";
		variant = "muted";
	} else if (stake > balance) sub = "Недостаточно $ROCKET";
	const onMain = () => {
		haptic();
		if (canCash) game.cashOut();
		else if (betOk) game.placeBet();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-3xl border border-border bg-card p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						"aria-label": "Уменьшить ставку",
						disabled: locked,
						onClick: () => game.setStake(stake - 10),
						className: "grid size-12 place-items-center rounded-2xl bg-elevated text-foreground transition active:scale-95 disabled:opacity-40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-12 flex-1 items-center justify-center gap-2 rounded-2xl border border-border bg-surface",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RocketCoin, { className: "size-5" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								inputMode: "numeric",
								"aria-label": "Сумма ставки",
								disabled: locked,
								value: stake,
								onChange: (e) => game.setStake(Number(e.target.value.replace(/\D/g, "")) || 0),
								className: "w-20 bg-transparent text-center font-display text-lg font-bold tabular-nums outline-none disabled:opacity-60"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-semibold text-muted-foreground",
								children: "$ROCKET"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						"aria-label": "Увеличить ставку",
						disabled: locked,
						onClick: () => game.setStake(stake + 10),
						className: "grid size-12 place-items-center rounded-2xl bg-elevated text-foreground transition active:scale-95 disabled:opacity-40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1.5",
				children: [
					50,
					100,
					250,
					500
				].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					disabled: locked,
					onClick: () => game.setStake(v),
					className: cn("flex-1 rounded-xl border py-1.5 text-xs font-bold transition disabled:opacity-40", stake === v ? "border-electric bg-accent text-cyan" : "border-border text-muted-foreground"),
					children: v
				}, v))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: onMain,
				disabled: !(canCash || betOk),
				className: cn("flex h-16 w-full flex-col items-center justify-center rounded-2xl font-display text-[15px] font-black tracking-wider transition active:scale-[0.98]", variant === "primary" && "bg-gradient-primary text-primary-foreground glow-blue disabled:opacity-50", variant === "success" && "bg-gradient-success text-background glow-success", variant === "muted" && "border border-border bg-elevated text-muted-foreground"),
				children: [label, sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 font-sans text-xs font-semibold tracking-normal opacity-80",
					children: sub
				})]
			})
		]
	});
}
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	className: cn("peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0") })
}));
Switch.displayName = Switch$1.displayName;
function AutoBetToggle() {
	const autoBet = useGame((s) => s.autoBet);
	const autoCash = useGame((s) => s.autoCash);
	const target = useGame((s) => s.autoTarget);
	const [draft, setDraft] = (0, import_react.useState)(target.toFixed(2));
	(0, import_react.useEffect)(() => setDraft(target.toFixed(2)), [target]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-2 gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex items-center justify-between rounded-2xl border border-border bg-card px-3 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-semibold",
				children: "Автоставка"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
				checked: autoBet,
				onCheckedChange: game.setAutoBet
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border border-border bg-card px-3 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-semibold",
					children: "Автовывод"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: autoCash,
					onCheckedChange: game.setAutoCash
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 flex items-center gap-1 text-xs text-muted-foreground",
				children: [
					"на",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						inputMode: "decimal",
						"aria-label": "Множитель автовывода",
						value: draft,
						onChange: (e) => setDraft(e.target.value.replace(",", ".")),
						onBlur: () => game.setAutoTarget(parseFloat(draft)),
						onKeyDown: (e) => e.key === "Enter" && e.target.blur(),
						className: "w-14 rounded-md bg-surface px-1.5 py-0.5 text-center font-display font-bold text-cyan outline-none focus:ring-1 focus:ring-ring"
					}),
					"x"
				]
			})]
		})]
	});
}
function maskName(name) {
	if (name.length <= 3) return name;
	const first = name.slice(0, 2);
	const last = name.slice(-2);
	return `${first}${name.slice(2, -2).replace(/[^_.]/g, "*")}${last}`;
}
function LiveBets() {
	const roundId = useGame((s) => s.roundId);
	const phase = useGame((s) => s.phase);
	const bet = useGame((s) => s.bet);
	const bots = useGame((s) => s.bots);
	const started = phase === "RUNNING" || phase === "CRASHED";
	const rows = bots.filter((b) => b.isPlaced).map((bot) => {
		return {
			id: bot.id,
			displayName: maskName(bot.name),
			amount: bot.amount,
			target: bot.target,
			cashed: bot.cashed,
			lost: bot.lost,
			payout: bot.cashed ? Math.floor(bot.amount * bot.target) : 0
		};
	});
	if (bet && bet.roundId === roundId) rows.unshift({
		id: -1,
		displayName: "Вы",
		amount: bet.amount,
		target: bet.cashedAt ?? 0,
		cashed: bet.status === "cashed",
		lost: bet.status === "lost",
		payout: bet.payout
	});
	const total = rows.reduce((sum, row) => sum + row.amount, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-3xl border border-border bg-card p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-bold",
					children: [
						"Ставки раунда",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-normal text-muted-foreground",
							children: ["· ", rows.length]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1 font-bold tabular-nums text-muted-foreground",
					children: [total.toLocaleString("ru-RU"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RocketCoin, { className: "size-3.5" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-[1fr_auto_auto] gap-x-3 px-2 pb-1 text-[10px] uppercase tracking-wider text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Игрок" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-right",
						children: "Ставка"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-24 text-right",
						children: "Вывод"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1",
				children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: cn("grid grid-cols-[1fr_auto_auto] items-center gap-x-3 rounded-xl px-2 py-1.5 text-sm transition-all duration-300", row.cashed ? "bg-success/10" : row.lost ? "bg-crash/10" : "bg-surface", row.id === -1 && "ring-1 ring-electric/60", phase === "COUNTDOWN" && row.id !== -1 && "animate-in fade-in slide-in-from-bottom-2"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate font-semibold",
							children: row.displayName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-right tabular-nums text-muted-foreground",
							children: row.amount.toLocaleString("ru-RU")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("w-24 text-right text-xs font-bold tabular-nums", row.cashed ? "text-success" : row.lost ? "text-crash" : "text-muted-foreground"),
							children: row.cashed ? `${row.target.toFixed(2)}x · +${row.payout}` : row.lost ? "Сгорела" : started ? "В полёте" : "Ждёт"
						})
					]
				}, row.id))
			})
		]
	});
}
function GamePage() {
	useGame((s) => s.phase);
	const [how, setHow] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 pt-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoundHistory, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RocketAnimation, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MultiplierDisplay, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BettingControls, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AutoBetToggle, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveBets, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
				open: how,
				onClose: () => setHow(false),
				title: "Как играть",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "list-decimal space-y-2 pl-5 text-foreground/90",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Сделайте виртуальную ставку до начала раунда." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Пока ракета летит, множитель растёт." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Заберите выигрыш до того, как ракета взорвётся." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "При успешном выводе выигрыш = ставка × множитель." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Если ракета взорвётся раньше — виртуальная ставка сгорает." })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 rounded-xl border border-gold/30 bg-gold/10 p-3 text-gold",
					children: "Это демо-прототип. Используются только виртуальные $ROCKET без реальной ценности — реальные деньги не принимаются и не выплачиваются. Результаты раундов генерируются в приложении для демонстрации."
				})]
			})
		]
	});
}
//#endregion
export { GamePage as component };
