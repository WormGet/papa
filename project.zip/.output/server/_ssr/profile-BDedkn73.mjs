import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as Key, o as ShieldAlert } from "../_libs/lucide-react.mjs";
import { a as cn, c as stats, d as useGame, n as StarsIcon, t as RocketCoin } from "./utils-Bv23y0fo.mjs";
import { i as useTelegramUser } from "./Modal-tszb9uE0.mjs";
import { t as Avatar } from "./Header-dJYhAU-G.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-BDedkn73.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProfilePage() {
	const s = useGame((x) => x);
	const u = useTelegramUser();
	const st = stats(s);
	const [dbUser, setDbUser] = (0, import_react.useState)(null);
	const [promoCode, setPromoCode] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const initData = (window.Telegram?.WebApp)?.initData || (typeof window !== "undefined" && window.location.hostname === "localhost" ? "user=%7B%22id%22%3A123%2C%22first_name%22%3A%22Admin%22%2C%22username%22%3A%22Egor_marki%22%7D" : "");
	const callApi = async (action, payload = {}) => {
		try {
			return await (await fetch("/api", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					initData,
					action,
					...payload
				})
			})).json();
		} catch (e) {
			console.error(e);
			return { error: "Network error" };
		}
	};
	(0, import_react.useEffect)(() => {
		if (initData) callApi("login").then((data) => {
			if (!data.error) setDbUser(data);
		});
	}, [initData]);
	const handlePromo = async () => {
		if (!promoCode || loading) return;
		setLoading(true);
		const res = await callApi("promo", { code: promoCode });
		if (res.success) {
			alert(res.message);
			setDbUser({
				...dbUser,
				balance: res.balance
			});
			setPromoCode("");
		} else alert(res.message || "Ошибка активации");
		setLoading(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 pt-3 pb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4 rounded-3xl border border-border bg-space p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, { size: "size-16" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-lg font-bold",
					children: u.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: u.demo ? "Демо-профиль" : `ID: ${u.id}`
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RocketCoin, {}), " Баланс сервера"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 font-display text-xl font-black",
						children: dbUser ? dbUser.balance.toLocaleString("ru-RU") : "..."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarsIcon, {}), " Telegram Stars"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 font-display text-xl font-black",
						children: s.stars
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card p-3 space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "text-sm font-bold flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, { size: 14 }), " Активировать промокод"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: promoCode,
						onChange: (e) => setPromoCode(e.target.value.toUpperCase()),
						className: "bg-surface p-2.5 rounded-xl w-full text-sm font-mono uppercase",
						placeholder: "FG34YH88ER",
						disabled: loading
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: handlePromo,
						disabled: loading,
						className: "bg-electric text-black px-4 rounded-xl font-bold text-sm disabled:opacity-50",
						children: loading ? "..." : "ОК"
					})]
				})]
			}),
			dbUser?.isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/admin",
				className: "flex items-center justify-center gap-2 bg-gold text-black py-3 rounded-2xl font-bold text-sm shadow-lg shadow-gold/20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { size: 18 }), " Открыть Админ-панель"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-2 text-center",
				children: [
					[
						"Ставок",
						st.total,
						"text-foreground"
					],
					[
						"Побед",
						st.wins,
						"text-success"
					],
					[
						"Поражений",
						st.losses,
						"text-crash"
					],
					[
						"Лучший",
						st.best ? `${st.best.toFixed(2)}x` : "—",
						"text-cyan"
					]
				].map(([l, v, c]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card px-1 py-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("font-display text-base font-black", c),
						children: v
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] text-muted-foreground",
						children: l
					})]
				}, l))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 text-sm font-bold text-muted-foreground",
				children: "Последние игры"
			}), s.games.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-dashed border-border p-4 text-center text-sm text-muted-foreground",
				children: "Пока нет сыгранных раундов"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1.5",
				children: s.games.slice(0, 10).map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between rounded-xl bg-card px-3 py-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: ["Ставка · ", g.amount]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("font-bold tabular-nums", g.win ? "text-success" : "text-crash"),
						children: g.win ? `+${g.payout} · ${g.cashedAt?.toFixed(2)}x` : `−${g.amount} · краш ${g.crashPoint.toFixed(2)}x`
					})]
				}, `${g.roundId}-${g.ts}`))
			})] })
		]
	});
}
//#endregion
export { ProfilePage as component };
