import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { f as Check, m as CalendarCheck, n as Wallet, s as Rocket } from "../_libs/lucide-react.mjs";
import { a as cn, d as useGame, l as taskKey, o as game, r as TASKS, t as RocketCoin, u as taskProgress } from "./utils-Bv23y0fo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tasks-BzDgD9gi.js
var import_jsx_runtime = require_jsx_runtime();
var ICONS = {
	rocket: Rocket,
	wallet: Wallet,
	calendar: CalendarCheck
};
function TasksPage() {
	const s = useGame((x) => x);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 pt-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-extrabold",
				children: "Задания"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Награды начисляются в виртуальных $ROCKET и не имеют реальной ценности."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2.5",
				children: TASKS.map((t) => {
					const Icon = ICONS[t.icon];
					const prog = Math.min(t.goal, taskProgress(s, t.id));
					const done = prog >= t.goal;
					const claimed = s.claimed.includes(taskKey(t.id));
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-2xl border border-border bg-card p-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid size-11 place-items-center rounded-xl bg-accent text-cyan",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-semibold",
										children: t.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-0.5 flex items-center gap-1 text-xs font-bold text-gold",
										children: [
											"+",
											t.reward,
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RocketCoin, { className: "size-3.5" })
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									disabled: !done || claimed,
									onClick: () => game.claimTask(t.id),
									className: cn("rounded-xl px-3.5 py-2 text-xs font-bold transition active:scale-95", claimed ? "bg-success/15 text-success" : done ? "bg-gradient-primary glow-blue" : "bg-elevated text-muted-foreground"),
									children: claimed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }), "Получено"]
									}) : done ? "Забрать" : `${prog}/${t.goal}`
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 h-1.5 overflow-hidden rounded-full bg-surface",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-full bg-gradient-primary transition-all",
								style: { width: `${prog / t.goal * 100}%` }
							})
						})]
					}, t.id);
				})
			})
		]
	});
}
//#endregion
export { TasksPage as component };
