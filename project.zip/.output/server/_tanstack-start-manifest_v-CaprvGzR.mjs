//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CaprvGzR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Egor/Desktop/chroma-round-tracker-main/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/events",
			"/profile",
			"/tasks"
		],
		preloads: ["/assets/index-ChXzi7lL.js", "/assets/createLucideIcon-DyQsxxdN.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ChXzi7lL.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/Egor/Desktop/chroma-round-tracker-main/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Bo_FqTXn.js", "/assets/Starfield-DrG09EiF.js"]
	},
	"/admin": {
		filePath: "C:/Users/Egor/Desktop/chroma-round-tracker-main/src/routes/admin.tsx",
		children: void 0,
		preloads: ["/assets/admin-1H3n7C6K.js", "/assets/shield-alert-zf1PF_tx.js"]
	},
	"/events": {
		filePath: "C:/Users/Egor/Desktop/chroma-round-tracker-main/src/routes/events.tsx",
		children: void 0,
		preloads: ["/assets/events-DTIzwu-U.js", "/assets/Starfield-DrG09EiF.js"]
	},
	"/profile": {
		filePath: "C:/Users/Egor/Desktop/chroma-round-tracker-main/src/routes/profile.tsx",
		children: void 0,
		preloads: ["/assets/profile-CYd3JjDx.js", "/assets/shield-alert-zf1PF_tx.js"]
	},
	"/tasks": {
		filePath: "C:/Users/Egor/Desktop/chroma-round-tracker-main/src/routes/tasks.tsx",
		children: void 0,
		preloads: ["/assets/tasks-Ci8PJR-r.js"]
	}
} });
//#endregion
export { tsrStartManifest };
